console.log("js failas");

vardas,
pavarde,
kelintaKlase,
matematikosPazymiai;

vardas = "Tomas";
pavarde = "Tomauskas";
kelintaKlase = "9";
matematikosPazymiai = "6, 5, 9, 10, 8";
console.log(vardas, pavarde, kelintaKlase, matematikosPazymiai
}
paz1 =6;
paz2 =5;
paz3 =9;
paz4 =10;
paz5 =8;

function countAverage (a1, a2, a3, a4, a5) {
  vidurkis = (a1 + a2 + a3 + a4 + a5) / 5;
  return vidurkis;
}

vid = countAverage (paz1, paz2, paz3, paz4, paz5);
console.log("Tomas, vidurkis: ", vid);
