console.log("js failas");

var name,
lastName,
age,
single;

name = "Tom";
lastName = "Jonson";
age = "89";
single = "0";

if (age > 18) {
  console.log("User is: adult")
} else {
  console.log("User is: not adult!");
}

if (name == "Tom") {
  console.log("User name is Tom");
}

 if (age >= 21 || name == "Tom") {
   console.log("Tomai, mes tau turime 5% nuolaida");
 }

if ( age >=65) {
  console.log("Sveikiname sulaukus tokio amziaus");
if (single) {
console.log("Sveiki, nemiegokite, yra dar laiko. Pas mus rasite zmona http//registrucentras.lt");
}
}else {
  console.log( "Kaupkite pas mus pensija");
}

age = 4;

if (age < 14) {
  console.log("atleisk, reikes teveliu pagalbos");
}else if (age >14 && age <18) {
  console.log("Populiariausi zaidimai http://zaisk.lt");
}else if (age >18 && age < 40) {
  console.log("Nestudijuok šu");
}

// spausdinu i ekrana
function printToConsole(x) {
console.log("Spausdinu: ", adax );
}

printToConsole("Tadas", 1)
printToConsole
printToConsole
printToConsole
